package com.arizona.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.arizona.launcher.databinding.ActivityMainBinding
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private var playerCount = 2847
    private val maxPlayers = 5000

    private val servers = listOf(
        "Arizona #1 — Main",
        "Arizona #2 — Premium",
        "Arizona #3 — PvP",
        "Arizona #4 — Test"
    )

    private val socialLinks = mapOf(
        R.id.btnDiscord to "https://discord.gg/arizonamobile",
        R.id.btnTelegram to "https://t.me/arizonamobile",
        R.id.btnVK to "https://vk.com/arizonamobile",
        R.id.btnForum to "https://forum.arizonamobile.gg"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupServerSelector()
        setupPlayButton()
        setupSocialButtons()
        setupTopBarButtons()
        startLiveUpdates()
    }

    private fun setupServerSelector() {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            servers
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerServer.adapter = adapter

        binding.spinnerServer.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                updateQueueStatus(position)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun updateQueueStatus(serverIndex: Int) {
        val queueSizes = listOf("No queue", "Queue: 5 players", "Queue: 18 players", "Queue: 2 players")
        binding.tvQueue.text = queueSizes[serverIndex]
        val color = when (serverIndex) {
            0 -> getColor(R.color.status_online)
            1 -> getColor(R.color.status_online)
            2 -> getColor(R.color.status_warning)
            else -> getColor(R.color.status_online)
        }
        binding.tvQueue.setTextColor(color)
    }

    private fun setupPlayButton() {
        binding.btnPlay.setOnClickListener {
            val intent = packageManager.getLaunchIntentForPackage("com.arizona.game")
            if (intent != null) {
                startActivity(intent)
            } else {
                Toast.makeText(this, "Arizona Mobile not installed", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun setupSocialButtons() {
        socialLinks.forEach { (viewId, url) ->
            findViewById<View>(viewId)?.setOnClickListener {
                openUrl(url)
            }
        }
    }

    private fun setupTopBarButtons() {
        binding.btnSettings.setOnClickListener {
            Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show()
        }
        binding.btnProfile.setOnClickListener {
            Toast.makeText(this, "Profile", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "No browser found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startLiveUpdates() {
        val runnable = object : Runnable {
            override fun run() {
                val change = Random.nextInt(-25, 26)
                playerCount = (playerCount + change).coerceIn(1200, maxPlayers - 10)
                binding.tvPlayers.text = "%,d / %,d".format(playerCount, maxPlayers)

                binding.dotStatus.alpha = if (System.currentTimeMillis() % 1000 < 500) 1.0f else 0.4f

                handler.postDelayed(this, 3000)
            }
        }
        handler.post(runnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
