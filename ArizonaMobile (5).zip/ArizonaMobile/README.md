# Arizona Mobile Launcher

A native Android launcher for Arizona Mobile with a dark RP-style aesthetic.

## Features

- Dark RP launcher aesthetic
- Live online player counter with animated status dot
- Server selector (4 servers) with queue status
- PLAY button launches `com.arizona.game`
- Social links (Discord, Telegram, VK, Forum)
- Settings & Profile buttons

## Build Instructions

### Android Studio

1. Download and install [Android Studio](https://developer.android.com/studio)
2. Open this folder (`File > Open`)
3. Wait for Gradle sync
4. Build APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`
5. APK location: `app/build/outputs/apk/debug/app-debug.apk`

### Command Line

```bash
./gradlew assembleDebug
```

## Tech Stack

- Kotlin
- Android SDK 34
- ConstraintLayout
- ViewBinding
- Material Design 3

## Project Structure

- `app/src/main/java/com/arizona/launcher/MainActivity.kt` — Launcher logic
- `app/src/main/res/layout/activity_main.xml` — Main UI
- `app/src/main/res/drawable/` — Backgrounds, buttons, icons
- `app/src/main/res/values/` — Colors, strings, themes

## Launch Target

The PLAY button attempts to launch the package `com.arizona.game`. If the app is not installed, it redirects to the Google Play Store page.
